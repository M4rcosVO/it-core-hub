﻿--
-- PostgreSQL database dump
--

\restrict dfLffeXHfXgsumhd2zOWQ7fxSRIwQGdsSOpd6rlTSwXTeMaaEuVBFm90PNnP05D

-- Dumped from database version 15.19
-- Dumped by pg_dump version 15.19

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: MobileStatus; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public."MobileStatus" AS ENUM (
    'DISPONIVEL',
    'EM_USO',
    'MANUTENCAO',
    'DESATIVADO',
    'EXTRAVIADO_ROUBADO'
);


ALTER TYPE public."MobileStatus" OWNER TO admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Acesso; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Acesso" (
    id integer NOT NULL,
    nome text NOT NULL,
    url text,
    usuario text NOT NULL,
    senha text NOT NULL,
    categoria text NOT NULL,
    setor text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Acesso" OWNER TO admin;

--
-- Name: Acesso_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."Acesso_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Acesso_id_seq" OWNER TO admin;

--
-- Name: Acesso_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."Acesso_id_seq" OWNED BY public."Acesso".id;


--
-- Name: AgendamentoRotina; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."AgendamentoRotina" (
    id integer NOT NULL,
    "rotinaId" integer,
    titulo text NOT NULL,
    data text NOT NULL,
    responsavel text NOT NULL,
    status text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AgendamentoRotina" OWNER TO admin;

--
-- Name: AgendamentoRotina_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."AgendamentoRotina_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."AgendamentoRotina_id_seq" OWNER TO admin;

--
-- Name: AgendamentoRotina_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."AgendamentoRotina_id_seq" OWNED BY public."AgendamentoRotina".id;


--
-- Name: Computer; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Computer" (
    id integer NOT NULL,
    hostname text NOT NULL,
    modelo text NOT NULL,
    processador text NOT NULL,
    ram text NOT NULL,
    armazenamento text NOT NULL,
    so text NOT NULL,
    responsavel text NOT NULL,
    setor text NOT NULL,
    status text NOT NULL,
    patrimonio text NOT NULL,
    "garantiaVencimento" text,
    "dataCompra" text,
    "termoAssinado" boolean DEFAULT false NOT NULL,
    historico jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Computer" OWNER TO admin;

--
-- Name: Computer_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."Computer_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Computer_id_seq" OWNER TO admin;

--
-- Name: Computer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."Computer_id_seq" OWNED BY public."Computer".id;


--
-- Name: Contrato; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Contrato" (
    id integer NOT NULL,
    fornecedor text NOT NULL,
    servico text NOT NULL,
    tipo text NOT NULL,
    vencimento text NOT NULL,
    "valorMensal" text NOT NULL,
    status text NOT NULL,
    "contatoNome" text,
    "contatoTelefone" text,
    "contatoEmail" text,
    sla text,
    observacoes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Contrato" OWNER TO admin;

--
-- Name: Contrato_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."Contrato_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Contrato_id_seq" OWNER TO admin;

--
-- Name: Contrato_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."Contrato_id_seq" OWNED BY public."Contrato".id;


--
-- Name: Demanda; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Demanda" (
    id integer NOT NULL,
    titulo text NOT NULL,
    descricao text NOT NULL,
    prioridade text NOT NULL,
    solicitante text NOT NULL,
    responsavel text NOT NULL,
    status text DEFAULT 'BACKLOG'::text NOT NULL,
    previsao text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Demanda" OWNER TO admin;

--
-- Name: Demanda_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."Demanda_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Demanda_id_seq" OWNER TO admin;

--
-- Name: Demanda_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."Demanda_id_seq" OWNED BY public."Demanda".id;


--
-- Name: DeviceAssignmentHistory; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."DeviceAssignmentHistory" (
    id integer NOT NULL,
    "deviceId" integer NOT NULL,
    "assignedTo" text NOT NULL,
    cpf text,
    department text NOT NULL,
    "phoneNumber" text NOT NULL,
    "signerIp" text,
    "termAcceptedAt" timestamp(3) without time zone NOT NULL,
    "returnedAt" timestamp(3) without time zone,
    "returnCondition" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."DeviceAssignmentHistory" OWNER TO admin;

--
-- Name: DeviceAssignmentHistory_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."DeviceAssignmentHistory_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."DeviceAssignmentHistory_id_seq" OWNER TO admin;

--
-- Name: DeviceAssignmentHistory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."DeviceAssignmentHistory_id_seq" OWNED BY public."DeviceAssignmentHistory".id;


--
-- Name: Emprestimo; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Emprestimo" (
    id integer NOT NULL,
    equipamento text NOT NULL,
    solicitante text NOT NULL,
    "dataRetirada" text NOT NULL,
    "previsaoDevolucao" text NOT NULL,
    status text NOT NULL,
    motivo text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Emprestimo" OWNER TO admin;

--
-- Name: Emprestimo_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."Emprestimo_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Emprestimo_id_seq" OWNER TO admin;

--
-- Name: Emprestimo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."Emprestimo_id_seq" OWNED BY public."Emprestimo".id;


--
-- Name: Incidente; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Incidente" (
    id integer NOT NULL,
    servico text NOT NULL,
    titulo text NOT NULL,
    data text NOT NULL,
    duracao text NOT NULL,
    "causaRaiz" text NOT NULL,
    resolucao text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Incidente" OWNER TO admin;

--
-- Name: Incidente_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."Incidente_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Incidente_id_seq" OWNER TO admin;

--
-- Name: Incidente_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."Incidente_id_seq" OWNED BY public."Incidente".id;


--
-- Name: Infraestrutura; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Infraestrutura" (
    id integer NOT NULL,
    tipo text NOT NULL,
    modelo text NOT NULL,
    ip text,
    local text NOT NULL,
    status text NOT NULL,
    patrimonio text NOT NULL,
    "garantiaVencimento" text,
    "dataCompra" text,
    historico jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Infraestrutura" OWNER TO admin;

--
-- Name: Infraestrutura_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."Infraestrutura_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Infraestrutura_id_seq" OWNER TO admin;

--
-- Name: Infraestrutura_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."Infraestrutura_id_seq" OWNED BY public."Infraestrutura".id;


--
-- Name: IpReservado; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."IpReservado" (
    id integer NOT NULL,
    ip text NOT NULL,
    dispositivo text NOT NULL,
    setor text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."IpReservado" OWNER TO admin;

--
-- Name: IpReservado_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."IpReservado_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."IpReservado_id_seq" OWNER TO admin;

--
-- Name: IpReservado_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."IpReservado_id_seq" OWNED BY public."IpReservado".id;


--
-- Name: Mobile; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Mobile" (
    id integer NOT NULL,
    modelo text NOT NULL,
    imei text NOT NULL,
    chip text,
    responsavel text NOT NULL,
    status text NOT NULL,
    patrimonio text NOT NULL,
    historico jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Mobile" OWNER TO admin;

--
-- Name: MobileDevice; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."MobileDevice" (
    id integer NOT NULL,
    imei text,
    brand text NOT NULL,
    model text NOT NULL,
    "phoneNumber" text,
    status public."MobileStatus" DEFAULT 'DISPONIVEL'::public."MobileStatus" NOT NULL,
    "assignedTo" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    department text,
    "deviceRawModel" text,
    "osVersion" text,
    "signerIp" text,
    "termAcceptedAt" timestamp(3) without time zone,
    cpf text,
    "deviceEmail" text,
    "deviceEmailPassword" text,
    "inPulsus" boolean DEFAULT false NOT NULL,
    "hasCable" boolean DEFAULT true NOT NULL,
    "hasCase" boolean DEFAULT false NOT NULL,
    "hasCharger" boolean DEFAULT true NOT NULL,
    "hasScreenProtector" boolean DEFAULT false NOT NULL,
    "returnNotes" text
);


ALTER TABLE public."MobileDevice" OWNER TO admin;

--
-- Name: MobileDevice_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."MobileDevice_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."MobileDevice_id_seq" OWNER TO admin;

--
-- Name: MobileDevice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."MobileDevice_id_seq" OWNED BY public."MobileDevice".id;


--
-- Name: Mobile_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."Mobile_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Mobile_id_seq" OWNER TO admin;

--
-- Name: Mobile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."Mobile_id_seq" OWNED BY public."Mobile".id;


--
-- Name: Peripheral; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Peripheral" (
    id integer NOT NULL,
    tipo text NOT NULL,
    modelo text NOT NULL,
    serial text NOT NULL,
    setor text NOT NULL,
    status text NOT NULL,
    ip text,
    patrimonio text NOT NULL,
    historico jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Peripheral" OWNER TO admin;

--
-- Name: Peripheral_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."Peripheral_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Peripheral_id_seq" OWNER TO admin;

--
-- Name: Peripheral_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."Peripheral_id_seq" OWNED BY public."Peripheral".id;


--
-- Name: Software; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."Software" (
    id integer NOT NULL,
    nome text NOT NULL,
    fabricante text NOT NULL,
    licenca text NOT NULL,
    qtd integer NOT NULL,
    assigned integer NOT NULL,
    vencimento text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Software" OWNER TO admin;

--
-- Name: Software_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."Software_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Software_id_seq" OWNER TO admin;

--
-- Name: Software_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."Software_id_seq" OWNED BY public."Software".id;


--
-- Name: User; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."User" (
    id integer NOT NULL,
    name text NOT NULL,
    password text NOT NULL,
    role text DEFAULT 'viewer'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."User" OWNER TO admin;

--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."User_id_seq" OWNER TO admin;

--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."User_id_seq" OWNED BY public."User".id;


--
-- Name: Acesso id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Acesso" ALTER COLUMN id SET DEFAULT nextval('public."Acesso_id_seq"'::regclass);


--
-- Name: AgendamentoRotina id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."AgendamentoRotina" ALTER COLUMN id SET DEFAULT nextval('public."AgendamentoRotina_id_seq"'::regclass);


--
-- Name: Computer id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Computer" ALTER COLUMN id SET DEFAULT nextval('public."Computer_id_seq"'::regclass);


--
-- Name: Contrato id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Contrato" ALTER COLUMN id SET DEFAULT nextval('public."Contrato_id_seq"'::regclass);


--
-- Name: Demanda id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Demanda" ALTER COLUMN id SET DEFAULT nextval('public."Demanda_id_seq"'::regclass);


--
-- Name: DeviceAssignmentHistory id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."DeviceAssignmentHistory" ALTER COLUMN id SET DEFAULT nextval('public."DeviceAssignmentHistory_id_seq"'::regclass);


--
-- Name: Emprestimo id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Emprestimo" ALTER COLUMN id SET DEFAULT nextval('public."Emprestimo_id_seq"'::regclass);


--
-- Name: Incidente id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Incidente" ALTER COLUMN id SET DEFAULT nextval('public."Incidente_id_seq"'::regclass);


--
-- Name: Infraestrutura id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Infraestrutura" ALTER COLUMN id SET DEFAULT nextval('public."Infraestrutura_id_seq"'::regclass);


--
-- Name: IpReservado id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."IpReservado" ALTER COLUMN id SET DEFAULT nextval('public."IpReservado_id_seq"'::regclass);


--
-- Name: Mobile id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Mobile" ALTER COLUMN id SET DEFAULT nextval('public."Mobile_id_seq"'::regclass);


--
-- Name: MobileDevice id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."MobileDevice" ALTER COLUMN id SET DEFAULT nextval('public."MobileDevice_id_seq"'::regclass);


--
-- Name: Peripheral id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Peripheral" ALTER COLUMN id SET DEFAULT nextval('public."Peripheral_id_seq"'::regclass);


--
-- Name: Software id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Software" ALTER COLUMN id SET DEFAULT nextval('public."Software_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."User" ALTER COLUMN id SET DEFAULT nextval('public."User_id_seq"'::regclass);


--
-- Data for Name: Acesso; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Acesso" (id, nome, url, usuario, senha, categoria, setor, "createdAt") FROM stdin;
\.


--
-- Data for Name: AgendamentoRotina; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."AgendamentoRotina" (id, "rotinaId", titulo, data, responsavel, status, "createdAt") FROM stdin;
\.


--
-- Data for Name: Computer; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Computer" (id, hostname, modelo, processador, ram, armazenamento, so, responsavel, setor, status, patrimonio, "garantiaVencimento", "dataCompra", "termoAssinado", historico, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Contrato; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Contrato" (id, fornecedor, servico, tipo, vencimento, "valorMensal", status, "contatoNome", "contatoTelefone", "contatoEmail", sla, observacoes, "createdAt") FROM stdin;
\.


--
-- Data for Name: Demanda; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Demanda" (id, titulo, descricao, prioridade, solicitante, responsavel, status, previsao, "createdAt") FROM stdin;
\.


--
-- Data for Name: DeviceAssignmentHistory; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."DeviceAssignmentHistory" (id, "deviceId", "assignedTo", cpf, department, "phoneNumber", "signerIp", "termAcceptedAt", "returnedAt", "returnCondition", "createdAt") FROM stdin;
\.


--
-- Data for Name: Emprestimo; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Emprestimo" (id, equipamento, solicitante, "dataRetirada", "previsaoDevolucao", status, motivo, "createdAt") FROM stdin;
\.


--
-- Data for Name: Incidente; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Incidente" (id, servico, titulo, data, duracao, "causaRaiz", resolucao, "createdAt") FROM stdin;
\.


--
-- Data for Name: Infraestrutura; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Infraestrutura" (id, tipo, modelo, ip, local, status, patrimonio, "garantiaVencimento", "dataCompra", historico, "createdAt") FROM stdin;
\.


--
-- Data for Name: IpReservado; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."IpReservado" (id, ip, dispositivo, setor, "createdAt") FROM stdin;
\.


--
-- Data for Name: Mobile; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Mobile" (id, modelo, imei, chip, responsavel, status, patrimonio, historico, "createdAt") FROM stdin;
\.


--
-- Data for Name: MobileDevice; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."MobileDevice" (id, imei, brand, model, "phoneNumber", status, "assignedTo", "createdAt", "updatedAt", department, "deviceRawModel", "osVersion", "signerIp", "termAcceptedAt", cpf, "deviceEmail", "deviceEmailPassword", "inPulsus", "hasCable", "hasCase", "hasCharger", "hasScreenProtector", "returnNotes") FROM stdin;
8	\N	Not A(Brand	Desconhecido	31995584478	EM_USO	Marcos Vin├¡cius de Oliveira	2026-10-09 13:52:46.678	2026-10-09 13:52:46.678	T.I	Desconhecido	Windows 10.0.0	172.18.0.1	2026-10-09 13:52:46.663	\N	\N	\N	f	t	f	t	f	\N
9	123456789123456	Not A(Brand	Desconhecido	31995584466	MANUTENCAO	Marcos Vin├¡cius	2026-10-09 13:58:47.481	2026-10-09 13:59:52.402	T.I	Desconhecido	Windows 10.0.0	172.18.0.1	2026-10-09 13:58:47.481	\N	\N	\N	f	t	f	t	f	\N
10	\N	Samsung	SM-A155M	(31) 98888-7777	EM_USO	Jo├â┬úo Silva da Portaria	2026-10-09 14:31:10.512	2026-10-09 15:46:20.77	Portaria	SM-A155M	Android 14	172.18.0.1	2026-10-09 15:46:19.885	123.456.789-00	\N	\N	f	t	f	t	f	\N
11	354890123456789	Motorola	Moto G84	(31) 99999-8888	DISPONIVEL	Analista de T.I	2026-10-09 15:46:58.551	2026-10-09 15:46:58.551	T.I	\N	\N	\N	\N	000.111.222-33	aparelho.ti@gellak.com.br	SecretPassword123!	t	t	f	t	f	\N
\.


--
-- Data for Name: Peripheral; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Peripheral" (id, tipo, modelo, serial, setor, status, ip, patrimonio, historico, "createdAt") FROM stdin;
\.


--
-- Data for Name: Software; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."Software" (id, nome, fabricante, licenca, qtd, assigned, vencimento, "createdAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."User" (id, name, password, role, "createdAt") FROM stdin;
1	admin.ti	$2b$10$zO2rs1UtNw0l1SmBDO6sE.6/Pz0UaIBNpbc6xlfC21KOhjopIkJVq	admin	2026-10-09 12:27:12.259
\.


--
-- Name: Acesso_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."Acesso_id_seq"', 1, false);


--
-- Name: AgendamentoRotina_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."AgendamentoRotina_id_seq"', 1, false);


--
-- Name: Computer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."Computer_id_seq"', 1, false);


--
-- Name: Contrato_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."Contrato_id_seq"', 1, false);


--
-- Name: Demanda_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."Demanda_id_seq"', 1, false);


--
-- Name: DeviceAssignmentHistory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."DeviceAssignmentHistory_id_seq"', 1, false);


--
-- Name: Emprestimo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."Emprestimo_id_seq"', 1, false);


--
-- Name: Incidente_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."Incidente_id_seq"', 1, false);


--
-- Name: Infraestrutura_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."Infraestrutura_id_seq"', 1, false);


--
-- Name: IpReservado_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."IpReservado_id_seq"', 1, false);


--
-- Name: MobileDevice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."MobileDevice_id_seq"', 13, true);


--
-- Name: Mobile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."Mobile_id_seq"', 1, false);


--
-- Name: Peripheral_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."Peripheral_id_seq"', 1, false);


--
-- Name: Software_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."Software_id_seq"', 1, false);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."User_id_seq"', 1, true);


--
-- Name: Acesso Acesso_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Acesso"
    ADD CONSTRAINT "Acesso_pkey" PRIMARY KEY (id);


--
-- Name: AgendamentoRotina AgendamentoRotina_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."AgendamentoRotina"
    ADD CONSTRAINT "AgendamentoRotina_pkey" PRIMARY KEY (id);


--
-- Name: Computer Computer_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Computer"
    ADD CONSTRAINT "Computer_pkey" PRIMARY KEY (id);


--
-- Name: Contrato Contrato_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Contrato"
    ADD CONSTRAINT "Contrato_pkey" PRIMARY KEY (id);


--
-- Name: Demanda Demanda_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Demanda"
    ADD CONSTRAINT "Demanda_pkey" PRIMARY KEY (id);


--
-- Name: DeviceAssignmentHistory DeviceAssignmentHistory_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."DeviceAssignmentHistory"
    ADD CONSTRAINT "DeviceAssignmentHistory_pkey" PRIMARY KEY (id);


--
-- Name: Emprestimo Emprestimo_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Emprestimo"
    ADD CONSTRAINT "Emprestimo_pkey" PRIMARY KEY (id);


--
-- Name: Incidente Incidente_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Incidente"
    ADD CONSTRAINT "Incidente_pkey" PRIMARY KEY (id);


--
-- Name: Infraestrutura Infraestrutura_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Infraestrutura"
    ADD CONSTRAINT "Infraestrutura_pkey" PRIMARY KEY (id);


--
-- Name: IpReservado IpReservado_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."IpReservado"
    ADD CONSTRAINT "IpReservado_pkey" PRIMARY KEY (id);


--
-- Name: MobileDevice MobileDevice_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."MobileDevice"
    ADD CONSTRAINT "MobileDevice_pkey" PRIMARY KEY (id);


--
-- Name: Mobile Mobile_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Mobile"
    ADD CONSTRAINT "Mobile_pkey" PRIMARY KEY (id);


--
-- Name: Peripheral Peripheral_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Peripheral"
    ADD CONSTRAINT "Peripheral_pkey" PRIMARY KEY (id);


--
-- Name: Software Software_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."Software"
    ADD CONSTRAINT "Software_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Computer_hostname_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "Computer_hostname_key" ON public."Computer" USING btree (hostname);


--
-- Name: Computer_patrimonio_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "Computer_patrimonio_key" ON public."Computer" USING btree (patrimonio);


--
-- Name: Infraestrutura_patrimonio_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "Infraestrutura_patrimonio_key" ON public."Infraestrutura" USING btree (patrimonio);


--
-- Name: IpReservado_ip_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "IpReservado_ip_key" ON public."IpReservado" USING btree (ip);


--
-- Name: MobileDevice_imei_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "MobileDevice_imei_key" ON public."MobileDevice" USING btree (imei);


--
-- Name: Mobile_imei_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "Mobile_imei_key" ON public."Mobile" USING btree (imei);


--
-- Name: Mobile_patrimonio_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "Mobile_patrimonio_key" ON public."Mobile" USING btree (patrimonio);


--
-- Name: Peripheral_patrimonio_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "Peripheral_patrimonio_key" ON public."Peripheral" USING btree (patrimonio);


--
-- Name: Peripheral_serial_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "Peripheral_serial_key" ON public."Peripheral" USING btree (serial);


--
-- Name: User_name_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "User_name_key" ON public."User" USING btree (name);


--
-- Name: DeviceAssignmentHistory DeviceAssignmentHistory_deviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."DeviceAssignmentHistory"
    ADD CONSTRAINT "DeviceAssignmentHistory_deviceId_fkey" FOREIGN KEY ("deviceId") REFERENCES public."MobileDevice"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict dfLffeXHfXgsumhd2zOWQ7fxSRIwQGdsSOpd6rlTSwXTeMaaEuVBFm90PNnP05D

